import sqlite3
import os
from werkzeug.utils import secure_filename
from flask import Flask, render_template, request

app = Flask(__name__)

UPLOAD_FOLDER = os.path.join("static", "uploads")
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif"}



def init_db():
    conn = sqlite3.connect("lost_found.db")

    conn.execute("""
        CREATE TABLE IF NOT EXISTS items (
        image TEXT
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_name TEXT,
            location TEXT,
            date TEXT,
            description TEXT,
            item_type TEXT
        )
    """)

    columns = conn.execute("PRAGMA table_info(items)").fetchall()
    column_names = [column[1] for column in columns]

    if "contact" not in column_names:
        conn.execute(
            "ALTER TABLE items ADD COLUMN contact TEXT"
        )

    if "status" not in column_names:
        conn.execute(
            "ALTER TABLE items ADD COLUMN status TEXT DEFAULT 'Available'"
        )

    if "category" not in column_names:
        conn.execute(
            "ALTER TABLE items ADD COLUMN category TEXT DEFAULT 'Other'"
        )

    if "image" not in column_names:
        conn.execute(
            "ALTER TABLE items ADD COLUMN image TEXT"
        )
        

    
    conn.execute("""
        CREATE TABLE IF NOT EXISTS items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_name TEXT,
            location TEXT,
            date TEXT,
            description TEXT,
            item_type TEXT,
            image TEXT
        )
    """)


    conn.commit()
    conn.close()



@app.route("/")
def home():
    conn = sqlite3.connect("lost_found.db")

    total_lost = conn.execute(
        "SELECT COUNT(*) FROM items WHERE item_type = 'lost'"
    ).fetchone()[0]

    total_found = conn.execute(
        "SELECT COUNT(*) FROM items WHERE item_type = 'found'"
    ).fetchone()[0]

    total_returned = conn.execute(
        "SELECT COUNT(*) FROM items WHERE status = 'Returned'"
    ).fetchone()[0]

    conn.close()

    return render_template(
        "index.html",
        total_lost=total_lost,
        total_found=total_found,
        total_returned=total_returned
    )


@app.route("/submit", methods=["POST"])
def submit():
    item_name = request.form.get("item_name")
    location = request.form.get("location")
    date = request.form.get("date")
    description = request.form.get("description")
    item_type = request.form.get("item_type")
    contact = request.form.get("contact")
    category = request.form.get("category", "Other")

    
    photo = request.files.get("item_image")
    image_filename = None

    if photo and photo.filename:
        filename = secure_filename(photo.filename)
        extension = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""

        if extension not in ALLOWED_EXTENSIONS:
            return "Invalid image type. Please upload JPG, JPEG, PNG, or GIF."

        os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
        photo.save(os.path.join(app.config["UPLOAD_FOLDER"], filename))
        image_filename = filename


    # Handle uploaded photo
    photo = request.files.get("item_image")
    image_filename = None

    if photo and photo.filename:
        filename = secure_filename(photo.filename)
        extension = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""

        if extension not in ALLOWED_EXTENSIONS:
            return "Invalid image type. Upload JPG, JPEG, PNG, or GIF."

        os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
        photo.save(os.path.join(app.config["UPLOAD_FOLDER"], filename))
        image_filename = filename

    conn = sqlite3.connect("lost_found.db")

    conn.execute("""
        INSERT INTO items
        (item_name, location, date, description, item_type, contact, category, image)
VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        item_name,
        location,
        date,
        description,
        item_type,
        contact,
        category,
        image_filename
    ))

    conn.commit()
    conn.close()

    if item_type == "lost":
        message = "🔴 Lost Item Reported Successfully!"
    else:
        message = "🟢 Found Item Reported Successfully!"

    return render_template("success.html", message=message)

@app.route("/lost-items")
def lost_items():
    conn = sqlite3.connect("lost_found.db")
    conn.row_factory = sqlite3.Row

    items = conn.execute(
        "SELECT * FROM items WHERE item_type = 'lost'"
    ).fetchall()

    conn.close()

    return render_template("lost_items.html", items=items)


@app.route("/found-items")
def found_items():
    conn = sqlite3.connect("lost_found.db")
    conn.row_factory = sqlite3.Row

    items = conn.execute(
        "SELECT * FROM items WHERE item_type = 'found'"
    ).fetchall()

    conn.close()

    return render_template("found_items.html", items=items)




@app.route("/search")
def search():
    query = request.args.get("q", "").strip().lower()
    category = request.args.get("category", "").strip()
    item_type = request.args.get("item_type", "").strip()

    conn = sqlite3.connect("lost_found.db")
    conn.row_factory = sqlite3.Row

    sql = "SELECT * FROM items WHERE LOWER(item_name) LIKE ?"
    params = ["%" + query + "%"]

    if category:
        sql += " AND category = ?"
        params.append(category)

    if item_type:
        sql += " AND item_type = ?"
        params.append(item_type)

    items = conn.execute(sql, params).fetchall()
    conn.close()

    return render_template(
        "search.html",
        items=items,
        query=query,
        selected_category=category,
        selected_type=item_type
    )


@app.route("/claim/<int:item_id>")
def claim_item(item_id):
    conn = sqlite3.connect("lost_found.db")
    conn.row_factory = sqlite3.Row

    item = conn.execute(
        "SELECT * FROM items WHERE id = ?",
        (item_id,)
    ).fetchone()

    conn.close()

    return render_template("claim.html", item=item)


@app.route("/submit-claim/<int:item_id>", methods=["POST"])
def submit_claim(item_id):
    claimant_name = request.form.get("claimant_name")
    claimant_contact = request.form.get("claimant_contact")
    message = request.form.get("message")

    conn = sqlite3.connect("lost_found.db")

    conn.execute("""
        INSERT INTO claims
        (item_id, claimant_name, claimant_contact, message)
        VALUES (?, ?, ?, ?)
    """, (
        item_id,
        claimant_name,
        claimant_contact,
        message
    ))

    conn.commit()
    conn.close()

    return "Claim submitted successfully!"


@app.route("/claims")
def claims():
    conn = sqlite3.connect("lost_found.db")
    conn.row_factory = sqlite3.Row

    claims = conn.execute("""
        SELECT
            claims.claimant_name,
            claims.claimant_contact,
            claims.message,
            items.item_name
        FROM claims
        JOIN items
        ON claims.item_id = items.id
    """).fetchall()

    conn.close()

    return render_template("claims.html", claims=claims)

@app.route("/return/<int:item_id>", methods=["POST"])
def mark_returned(item_id):
    conn = sqlite3.connect("lost_found.db")

    conn.execute(
        "UPDATE items SET status = 'Returned' WHERE id = ?",
        (item_id,)
    )

    conn.commit()
    conn.close()

    return "Item marked as returned successfully!"


@app.route("/delete/<int:item_id>", methods=["POST"])
def delete_item(item_id):
    conn = sqlite3.connect("lost_found.db")

    conn.execute(
        "DELETE FROM items WHERE id = ?",
        (item_id,)
    )

    conn.commit()
    conn.close()

    return "Item deleted successfully!"


@app.route("/edit/<int:item_id>")
def edit_item(item_id):
    conn = sqlite3.connect("lost_found.db")
    conn.row_factory = sqlite3.Row

    item = conn.execute(
        "SELECT * FROM items WHERE id = ?",
        (item_id,)
    ).fetchone()

    conn.close()

    return render_template("edit_item.html", item=item)



@app.route("/update/<int:item_id>", methods=["POST"])
def update_item(item_id):
    item_name = request.form.get("item_name")
    location = request.form.get("location")
    date = request.form.get("date")
    description = request.form.get("description")
    contact = request.form.get("contact")
    category = request.form.get("category", "Other")

    conn = sqlite3.connect("lost_found.db")

    conn.execute("""
        UPDATE items
        SET item_name = ?,
            location = ?,
            date = ?,
            description = ?,
            contact = ?,
            category = ?
        WHERE id = ?
    """, (
        item_name,
        location,
        date,
        description,
        contact,
        category,
        item_id
    ))

    conn.commit()
    conn.close()

    return "Item updated successfully!"


init_db()


if __name__ == "__main__":
    app.run(debug=True)